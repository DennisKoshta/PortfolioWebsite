# README
## Multi-threaded HTTP Server

This project implements a multi-threaded HTTP server that serves multiple clients simultaneously using a thread-safe queue. The server ensures that its responses conform to a coherent and atomic linearization of the client requests and creates an audit log to identify the linearization.

## Overview
The server takes two command line arguments, `port` - the port to listen on, and `threads` - the number of worker threads to use. The `port` argument is required, and the `threads` argument is optional (defaulting to 4).

```
./httpserver [-t threads] <port>
```

The server processes multiple clients simultaneously while ensuring the coherency and atomicity of its responses. It produces an audit log on stderr that indicates the order in which it processed requests.

## HTTP Request and Response Format

This server supports a simplified subset of the HTTP protocol, specifically the GET and PUT methods. Below, we describe the format of HTTP requests and responses that the server should handle, as well as the processing for GET and PUT commands.

### Requests

GET and PUT requests share the same format, containing required and optional fields. Each field is separated by the sequence `\r\n`. Here is the structure of a request:

```
Request-Line\r\n [Required]
(Header-Field\r\n)* [Optional, repeated]
\r\n
Message-Body [Optional]
```

A valid request's characters up to and including the "double" `\r\n` will not exceed 2048 characters (this includes the length of the Request-Line, all Header-Fields, and all `\r\n` delimiters).

#### Request-Line

Every valid request includes exactly one request-line with the following format:

```
Method URI Version
```

A valid request-line will contain at most 2048 characters. We limit valid requests in the following ways:

- The only methods implemented are GET and PUT.

- A valid URI points to a file path in your current directory.

- `HTTP/1.1` is the only valid version.

### Responses

The server produces a response for each request, regardless of whether the request is valid or not:

```
Status-Line\r\n [Required]
(Header-Field\r\n)* [Optional, repeated]
\r\n
Message-Body [Optional]
```

#### Status-Line

The status line indicates the type of response to the request. It consists of three fields:

```
HTTP-Version Status-Code Status-Phrase
```

The httpserver must always produce the HTTP-Version string, `HTTP/1.1`, regardless of the HTTP-Version provided in the request.

## Requirements

1. Install Clang:
   - For Ubuntu or Debian-based systems, run:
     ```
     sudo apt-get install clang
     ```
   - For macOS, install Xcode command line tools:
     ```
     xcode-select --install
     ```
   - For Windows, follow the instructions on Clang's official website: https://releases.llvm.org/download.html

## Building and Running

To build the `httpserver` binary, navigate to the `asgn4` directory and execute the following command:

```
make
```

To run the server, execute the following command, replacing `<port>` with the desired listening port, and optionally specifying the number of worker threads with the `-t` flag:

```
./httpserver [-t threads] <port>
```

## Audit Log

The server produces an audit log on stderr with the following format for each request:

```
<Oper>,<URI>,<Status-Code>,<RequestID header value>\n
```

The audit log ensures atomicity and durability of the log entries. The server's linearization of requests must conform to the order of requests it received.

## Multi-threading

The server uses a thread-pool design, with worker threads processing requests and a dispatcher thread listening for connections and dispatching them to the workers. The dispatcher and worker threads must synchronize correctly to ensure proper request processing and maintain the server's state.